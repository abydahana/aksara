<section class="slider_section bg-dark gradient" style="background:url(<?php echo get_theme_asset('images/hero-bg.jpg'); ?>) center center no-repeat; background-size:cover">
	<div id="customCarousel1" class="carousel slide" data-ride="carousel">
		<div class="carousel-inner">
			<?php
				$spotlight_navigation				= null;
				
				if($spotlight)
				{
					foreach($spotlight as $key => $val)
					{
						$spotlight_navigation		.= '<li data-target="#customCarousel1" data-slide-to="' . $key . '" class="' . (!$key ? 'active' : null) . '"></li>';
						
						echo '
							<div class="carousel-item' . (!$key ? ' active' : null) . '">
								<div class="container ">
									<div class="row">
										<div class="col-md-7 col-lg-6">
											<div class="detail-box text-center text-lg-left text-xl-left">
												<h2>
													' . $val->post_title . '
												</h2>
												<p>
													' . $val->post_excerpt . '
												</p>
												<div class="btn-box">
													<a href="' . ($_val->post_slug ? go_to($val->category_slug . '/' . $_val->post_slug) : go_to('blogs', array('post_id' => $_val->post_id))) . '" class="btn1">
														Read Mote
													</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						';
					}
				}
			?>
		</div>
		<div class="container text-center text-lg-left text-xl-left">
			<ol class="carousel-indicators">
				<?php echo $spotlight_navigation; ?>
			</ol>
		</div>
	</div>

</section>

<!-- offer section -->

<section class="offer_section layout_padding-bottom">
	<div class="offer_container">
		<div class="container ">
			<div class="row">
				<div class="col-md-6">
					<div class="box rounded-more">
						<div class="img-box">
							<img src="<?php echo get_theme_asset('images/o1.jpg'); ?>" alt="">
						</div>
						<div class="detail-box">
							<h5>
								Tasty Thursdays
							</h5>
							<h6>
								<span>20%</span> Off
							</h6>
							<a href="javascript:void(0)">
								Order Now
							</a>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="box rounded-more">
						<div class="img-box">
							<img src="<?php echo get_theme_asset('images/o2.jpg'); ?>" alt="">
						</div>
						<div class="detail-box">
							<h5>
								Pizza Days
							</h5>
							<h6>
								<span>15%</span> Off
							</h6>
							<a href="javascript:void(0)">
								Order Now
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- end offer section -->

<!-- food section -->

<section class="food_section layout_padding-bottom">
	<div class="container">
		<div class="heading_container heading_center">
			<h2>
				Our Menu
			</h2>
		</div>
		<?php
			$categories								= null;
			$items									= null;
			
			if($articles)
			{
				foreach($articles as $key => $val)
				{
					$categories						.= '<li data-filter=".' . sha1($val->category_slug) . '">' . $val->category_title . '</li>';
					
					if($val->posts)
					{
						foreach($val->posts as $_key => $_val)
						{
							$items					.= '
								<div class="col-sm-6 col-lg-3 all ' . sha1($val->category_slug) . '">
									<div class="box">
										<div>
											<div class="img-box">
												<a href="' . ($_val->post_slug ? go_to($val->category_slug . '/' . $_val->post_slug) : go_to('blogs', array('post_id' => $_val->post_id))) . '" class="--xhr font-weight-bold text-light">
													<img src="' . get_image('blogs', $_val->featured_image, 'thumb') . '" class="img-fluid rounded-circle" alt="' . $_val->post_title . '">
												</a>
											</div>
											<div class="detail-box">
												<a href="' . ($_val->post_slug ? go_to($val->category_slug . '/' . $_val->post_slug) : go_to('blogs', array('post_id' => $_val->post_id))) . '" class="--xhr font-weight-bold text-light">
													<h5 class="text-truncate">
														' . $_val->post_title . '
													</h5>
												</a>
												<p>
													' . truncate($_val->post_excerpt, 100) . '
												</p>
												<div class="options">
													<h6>
														<span class="text-sm">
															' . time_ago($_val->updated_timestamp) . '
														</span>
													</h6>
													<a href="' . ($_val->post_slug ? go_to($val->category_slug . '/' . $_val->post_slug) : go_to('blogs', array('post_id' => $_val->post_id))) . '" class="--xhr font-weight-bold text-light">
														<i class="mdi mdi-magnify"></i>
													</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							';
							
						}
					}
				}
			}
		?>
		<ul class="filters_menu">
			<li class="active" data-filter="*"><?php echo phrase('all_posts'); ?></li>
			<?php echo $categories; ?>
		</ul>
		<div class="filters-content">
			<div class="row grid">
				<?php echo $items; ?>
			</div>
		</div>
		<div class="btn-box">
			<a href="<?php echo base_url('blogs'); ?>" class="--xhr">
				View More
			</a>
		</div>
	</div>
</section>

<!-- end food section -->

<!-- about section -->

<section class="about_section layout_padding">
	<div class="container">

		<div class="row">
			<div class="col-md-6 ">
				<div class="img-box">
					<img src="<?php echo get_theme_asset('images/about-img.png'); ?>" alt="">
				</div>
			</div>
			<div class="col-md-6">
				<div class="detail-box text-center text-lg-left text-xl-left">
					<div class="heading_container">
						<h2>
							We Are Feane
						</h2>
					</div>
					<p>
						There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All
					</p>
					<a href="javascript:void(0)">
						Read More
					</a>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- end about section -->

<!-- client section -->
<section class="client_section layout_padding">
	<div class="container">
		<div class="heading_container heading_center psudo_white_primary mb_45">
			<h2>
				What Says Our Customers
			</h2>
		</div>
		<div class="swiper-container swiper" data-sm-items="1" data-md-items="2" data-lg-items="2" data-space-between="30" data-autoplay="1" data-navigation="0">
			<div class="swiper-wrapper">
				<?php
					/**
					 * Latest testimonials
					 */
					if(isset($testimonials) && $testimonials)
					{
						foreach($testimonials as $key => $val)
						{
							echo '
								<div class="swiper-slide">
									<div class="box">
										<div class="detail-box rounded-more">
											<p>
												' . truncate($val->testimonial_content, 160) . '
											</p>
											<h6>
												' . $val->first_name . ' ' . $val->last_name . '
											</h6>
											<p class="text-sm">
												' . date('d F Y', strtotime($val->timestamp)) . '
											</p>
										</div>
										<div class="img-box" style="width:100px">
											<img src="' . get_image('testimonials', $val->photo, 'thumb') . '" alt="" class="box-img img-fluid">
										</div>
									</div>
								</div>
							';
						}
					}
				?>
			</div>
		</div>
	</div>
</section>
