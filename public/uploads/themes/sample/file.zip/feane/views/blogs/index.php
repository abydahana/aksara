<div class="leading pt-5 pb-5 mb-5 bg-light relative" style="background: url(<?php echo get_theme_asset('images/hero-bg.jpg'); ?>) center center no-repeat; background-size: cover">
	<div class="clip gradient-top"></div>
	<div class="container pt-5 pb-5">
		<div class="row">
			<div class="col-md-8 offset-md-2">
				<h1 class="text-center text-light">
					<?php echo $meta->title; ?>
				</h1>
				<p class="lead text-center text-light mb-5">
					<?php echo truncate($meta->description, 256); ?>
				</p>
			</div>
		</div>
		<div class="row">
			<div class="col-md-8 offset-md-2 col-lg-6 offset-lg-3">
				<form action="<?php echo base_url('blogs/search', array('per_page' => null)); ?>" method="POST" class="form-horizontal relative --xhr-form">
					<input type="text" name="q" class="form-control form-control-lg pt-4 pr-4 pb-4 pl-4 border-0 rounded-pill" placeholder="<?php echo phrase('search_post'); ?>" />
					<button type="submit" class="btn btn-lg float-right absolute top right">
						<i class="mdi mdi-magnify font-weight-bold"></i>
					</button>
				</form>
			</div>
		</div>
	</div>
</div>

<div class="">
	<div class="container food_section">
		<?php
			$posts									= null;
			
			foreach($spotlight as $key => $val)
			{
				$posts								.= '
					<div class="swiper-slide">
						<div class="box mb-3">
							<div>
								<div class="img-box">
									<a href="' . base_url(array('blogs', $val->category_slug, $val->post_slug)) . '" class="--xhr">
										<img src="' . get_image('blogs', $val->featured_image, 'thumb') . '" class="img-fluid rounded-circle" alt="...">
									</a>
								</div>
								<div class="detail-box">
									<a href="' . base_url(array('blogs', $val->category_slug, $val->post_slug)) . '" class="--xhr">
										<h5 class="text-warning text-truncate">
											' . truncate($val->post_title, 80) . '
										</h5>
									</a>
									<p>
										' . truncate($val->post_excerpt, 100) . '
									</p>
									<div class="options">
										<h6 class="text-sm">
											<i class="mdi mdi-clock-outline"></i> ' . time_ago($val->updated_timestamp) . '
										</h6>
										<a href="' . base_url(array('blogs', $val->category_slug, $val->post_slug)) . '" class="--xhr">
											<i class="mdi mdi-magnify text-light"></i>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				';
			}
				
			echo '
				<h3 class="text-center text-md-left text-primary pt-3 mb-0 text-uppercase">
					' . phrase('spotlight') . '
				</h3>
				<p class="text-center text-md-left">
					' . phrase('an_article_spotlight_you_may_want_to_know') . '
				</p>
				<div class="swiper-container swiper" data-sm-items="1" data-md-items="2" data-lg-items="3" data-autoplay="1" data-space-between="30" data-navigation="1">
					<div class="swiper-wrapper">
						' . $posts . '
					</div>
				</div>
			';
		?>
	</div>
</div>

<div class="">
	<div class="container food_section">
		<?php
			foreach($articles as $key => $val)
			{
				$posts								= null;
				
				foreach($val->posts as $_key => $_val)
				{
					$posts							.= '
						<div class="swiper-slide">
							<div class="box mb-3">
								<div>
									<div class="img-box">
										<a href="' . base_url(array('blogs', $val->category_slug, $_val->post_slug)) . '" class="--xhr">
											<img src="' . get_image('blogs', $_val->featured_image, 'thumb') . '" class="img-fluid rounded-circle" alt="...">
										</a>
									</div>
									<div class="detail-box">
										<a href="' . base_url(array('blogs', $val->category_slug, $_val->post_slug)) . '" class="--xhr">
											<h5 class="text-warning text-truncate">
												' . truncate($_val->post_title, 80) . '
											</h5>
										</a>
										<p>
											' . truncate($_val->post_excerpt, 100) . '
										</p>
										<div class="options">
											<h6 class="text-sm">
												<i class="mdi mdi-clock-outline"></i> ' . time_ago($_val->updated_timestamp) . '
											</h6>
											<a href="' . base_url(array('blogs', $val->category_slug, $_val->post_slug)) . '" class="--xhr">
												<i class="mdi mdi-magnify text-light"></i>
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					';
				}
				
				echo '
					<a href="' . base_url(array('blogs', $val->category_slug)) . '" class="--xhr">
						<h3 class="text-center text-md-left text-primary pt-5 mb-0">
							' . $val->category_title . '
						</h3>
					</a>
					<p class="text-center text-md-left">
						' . $val->category_description . '
					</p>
					<div class="swiper-container swiper" data-sm-items="1" data-md-items="2" data-lg-items="4" data-autoplay="1" data-space-between="30" data-navigation="1">
						<div class="swiper-wrapper">
							' . $posts . '
						</div>
					</div>
				';
			}
		?>
	</div>
</div>
