// isotope js
$(document).ready(function()
{
	$('.grid').isotope
	({
		itemSelector: '.all'
	}),
	
	$('body').on('click', '.filters_menu li', function()
	{
		var _this									= $(this);
		
		$('.filters_menu li').removeClass('active'),
		
		_this.addClass('active'),
		
		$('.grid').isotope
		({
			itemSelector: '.all',
			filter: _this.attr('data-filter')
		})
	})
});
