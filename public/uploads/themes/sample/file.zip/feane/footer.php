<div class="aksara-footer bg-white pt-5">
	<footer class="footer_section">
		<div class="container">
			<div class="row">
				<div class="col-md-4 footer-col">
					<div class="footer_contact">
						<h4>
							Contact Us
						</h4>
						<div class="contact_link_box">
							<a href="<?php echo base_url('pages/contact'); ?>" class="--xhr">
								<span>
									<?php echo (get_setting('office_name') ? get_setting('office_name') : phrase('non_profit')); ?>
								</span>
							</a>
							<a href="<?php echo base_url('pages/contact'); ?>" class="--xhr">
								<i class="mdi mdi-map-marker" aria-hidden="true"></i>
								<span>
									<?php echo nl2br(get_setting('office_address')); ?>
								</span>
							</a>
							<a href="<?php echo base_url('pages/contact'); ?>" class="--xhr">
								<i class="mdi mdi-at" aria-hidden="true"></i>
								<span>
									<?php echo get_setting('office_email'); ?>
								</span>
							</a>
							<a href="<?php echo base_url('pages/contact'); ?>" class="--xhr">
								<i class="mdi mdi-phone" aria-hidden="true"></i>
								<span>
									<?php echo get_setting('office_phone'); ?>
								</span>
							</a>
						</div>
					</div>
				</div>
				<div class="col-md-4 footer-col">
					<div class="footer_detail">
						<a href="javascript:void(0)" class="footer-logo">
							<?php echo get_setting('app_name'); ?>
						</a>
						<p>
							<?php echo get_setting('app_description'); ?>
						</p>
						<div class="footer_social">
							<a href="//api.whatsapp.com/send?phone=<?php echo str_replace(array('+', '-', ' '), array(null, null, null), get_setting('whatsapp_number')); ?>&text=<?php echo phrase('hello') . '%20' . get_setting('app_name'); ?>..." target="_blank">
								<i class="mdi mdi-whatsapp" aria-hidden="true"></i>
							</a>
							<a href="//twitter.com/<?php echo get_setting('twitter_username'); ?>" target="_blank">
								<i class="mdi mdi-twitter" aria-hidden="true"></i>
							</a>
							<a href="//facebook.com/<?php echo get_setting('facebook_username'); ?>" target="_blank">
								<i class="mdi mdi-facebook" aria-hidden="true"></i>
							</a>
						</div>
					</div>
				</div>
				<div class="col-md-4 footer-col">
					<h4>
						Opening Hours
					</h4>
					<p>
						Everyday
					</p>
					<p>
						10.00 Am -10.00 Pm
					</p>
				</div>
			</div>
			<div class="footer-info">
				<div class="text-center">
					<small class="font-weight-bold">
						<?php echo phrase('copyright'); ?> &#169;<?php echo date('Y'); ?> - <?php echo get_setting('office_name'); ?>
					</small>
					<small>
						(<a href="<?php echo base_url('pages/about'); ?>" class="font-weight-bold text-light --xhr">Aksara <?php echo aksara('built_version'); ?></a>)
					</small>
				</div>
				<div class="row">
					<div class="col-md-8 offset-md-2">
						<div class="text-center text-muted text-sm font-weight-light mb-0">
							Feane theme by <a href="//themewagon.com/themes/free-bootstrap-4-html5-restaurant-website-template-feane" class="text-light" target="_blank">ThemeWagon</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>
