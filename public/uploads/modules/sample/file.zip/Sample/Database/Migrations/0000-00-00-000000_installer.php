<?php

namespace Modules\Sample\Database\Migrations;

/**
 * namespace Modules\$path\Database\Migrations;
 * The $path indicates for current module path
 */

use CodeIgniter\Database\Migration;

class Installer extends Migration
{
    public function up()
    {
		// run backward migration for safe re-installation
		$this->down();
		
		// prepare to create sample table
		$this->forge->addField
		(
			array
			(
				'id' => array
				(
					'type' => 'int',
					'constraint' => 11,
					'unsigned' => true,
					'auto_increment' => true,
					'null' => false
				),
				'title' => array
				(
					'type' => 'varchar',
					'constraint' => 255
				),
				'description' => array
				(
					'type' => 'varchar',
					'constraint' => 255
				),
				'timestamp' => array
				(
					'type' => 'timestamp'
				),
				'status' => array
				(
					'type' => 'tinyint',
					'constraint' => 1,
					'default' => '0',
					'null' => false
				)
			)
		);
		
		// add primary key to column `id`
		$this->forge->addKey('id', true, true);
		
		// create `sample__module` table
		$this->forge->createTable('sample__module');
	}
	
	public function down()
	{
		// drop table for safe re-installation
		$this->forge->dropTable('sample__module', true, true);
	}
}
