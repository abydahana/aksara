<?php

namespace Modules\Sample\Controllers;

/**
 * namespace Modules\$path\Controllers;
 * The $path indicates for current module path
 */

/**
 * Sample module
 *
 * @author			Aby Dahana
 * @profile			abydahana.github.io
 * @website			www.aksaracms.com
 * @since			version 4.0.0
 * @copyright		(c) 2021 - Aksara Laboratory
 */

class Sample extends \Aksara\Laboratory\Core
{
	private $_table									= 'sample__module'; // the table created from migration
	
	public function __construct()
	{
		parent::__construct();
	}
	
	public function index()
	{
		$this->set_title('Sample Module')
		->set_icon('mdi mdi-dropbox')
		->render($this->_table);
	}
}
