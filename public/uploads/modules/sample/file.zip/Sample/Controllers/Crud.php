<?php

namespace Modules\Sample\Controllers;

/**
 * namespace Modules\$path\Controllers;
 * The $path indicates for current module path
 */

/**
 * Sample CRUD module
 *
 * @author			Aby Dahana
 * @profile			abydahana.github.io
 * @website			www.aksaracms.com
 * @since			version 4.0.0
 * @copyright		(c) 2021 - Aksara Laboratory
 */

class Crud extends \Aksara\Laboratory\Core
{
	private $_table									= 'sample__module'; // the table created from migration
	
	public function __construct()
	{
		parent::__construct();
		
		$this->set_permission();
		$this->set_theme('backend');
	}
	
	public function index()
	{
		$this->set_title('Sample CRUD Module')
		->set_icon('mdi mdi-dropbox')
		
		->unset_column('id')
		->unset_field('id, timestamp')
		->unset_view('id')
		
		->set_validation
		(
			array
			(
				'title'								=> 'required',
				'description'						=> 'required',
				'status'							=> 'boolean'
			)
		)
		
		->set_field
		(
			array
			(
				'description'						=> 'textarea',
				'timestamp'							=> 'current_timestamp',
				'status'							=> 'boolean'
			)
		)
		
		->render($this->_table);
	}
}
