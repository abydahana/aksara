<div class="jumbotron jumbotron-fluid bg-light gradient">
	<div class="container">
		<div class="text-center text-md-left">
			<h3 class="mb-0<?php echo (!$meta->description ? ' mt-3' : null); ?>">
				<?php echo $meta->title; ?>
			</h3>
			<p class="lead">
				<?php echo truncate($meta->description, 256); ?>
			</p>
		</div>
	</div>
</div>

<div class="container pt-3 pb-3">
	<div class="row">
		<div class="col-md-10 offset-1">
			<?php
				if($results)
				{
					foreach($results as $key => $val)
					{
						echo '
							<blockquote class="blockquote' . ($key ? ' mt-5' : null) . '">
								<h5 class="mb-0">
									' . $val->title . '
								</h5>
								<p class="lead">
									' . $val->description . '
								</p>
								<footer class="blockquote-footer">
									' . phrase('updated_at') . ' ' . $val->timestamp . '
								</footer>
							</blockquote>
						';
					}
					
					echo $template->pagination;
				}
				else
				{
					echo '
						<div class="alert alert-warning">
							<i class="mdi mdi-information"></i>
							' . phrase('no_item_is_available') . '
						</div>
					';
				}
			?>
		</div>
	</div>
</div>
